<footer class="container mt-4 text-center p-2">
    <hr>
    <p>© 2024 University of Heaven. All rights reserved.</p>
    <a href="#" style="pointer-events: none; text-decoration: none;" >Exam Schedules</a> | <a href="#" style="pointer-events: none; text-decoration: none;">Results</a> | <a href="#" style="pointer-events: none; text-decoration: none;">FAQ</a>
</footer>